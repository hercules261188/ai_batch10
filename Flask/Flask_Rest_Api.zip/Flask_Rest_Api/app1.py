l1 = ["eat", "sleep", "play"]

for ind in enumerate(l1):
    print(ind)