from flask import Flask
from flask_restful import Resource, Api

app = Flask(__name__)
api = Api(app)

persons = []
class PersonName(Resource):

    def get(self, name):
        
        for per in persons:
            if per['name'] == name:
                return per    
        return {'name':None}
        

    def post(self, name):
        per = {'name':name}
        persons.append(per)
        return per

    def delete(self, name):
        
        for ind, per in enumerate(persons):
            if per['name'] == name:
                delete_per = persons.pop(ind)
                return {'note': 'delete sucessfull'}

class AllNames(Resource):

    def get(self):
        return {"persons":persons}

api.add_resource(PersonName, '/person/<string:name>')
api.add_resource(AllNames,'/persons')

if __name__ == '__main__':
    app.run(debug=True)